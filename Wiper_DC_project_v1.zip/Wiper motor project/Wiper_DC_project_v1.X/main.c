/*
� [2023] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
//#include "mcc_generated_files/X2Cscope/X2Cscope.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/mcp802x/mcp8021.h"
#include "mcc_generated_files/mcp802x/MCP802X_task.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/adc/adc1.h"

// Specify bootstrap charging time in Seconds (mention at least 10mSecs)
#define BOOTSTRAP_CHARGING_TIME_SECS 0.01
  /* Specify PWM Period in seconds, (1/ PWMFREQUENCY_HZ) */
#define LOOPTIME_SEC            0.00005

// Calculate Bootstrap charging time in number of PWM Half Cycles
#define BOOTSTRAP_CHARGING_COUNTS (uint16_t)((BOOTSTRAP_CHARGING_TIME_SECS/LOOPTIME_SEC )* 2)

// MC PWM MODULE Related Definitions
#define INVERTERA_PWM_PDC1      PG1DC
#define INVERTERA_PWM_PDC2      PG2DC
#define INVERTERA_PWM_PDC3      PG3DC
    
/* Specify PWM Period in micro seconds */
#define LOOPTIME_MICROSEC       50
/* Specify dead time in micro seconds */
#define DEADTIME_MICROSEC       1

#define FOSC_MHZ 20000000

// loop time in terms of PWM clock period
#define LOOPTIME_TCY            (uint16_t)(((LOOPTIME_MICROSEC*FOSC_MHZ)/2)-1)
       
#define DDEADTIME               (uint16_t)(DEADTIME_MICROSEC*FOSC_MHZ)

#define MCP802X_ENABLE_SetHigh()          (_LATC13 = 1)
#define MCP802X_ENABLE_SetLow()           (_LATC13 = 0)

MCP802X_STATE mcp8021_CommState;

#define FCY 200000000
#include <libpic30.h>
#include <stdio.h>
/*
    Main application
*/
void PWMInitialization2(void);
void ChargeBootstarpCapacitors(void);
volatile uint16_t faultHappen = 0;
volatile uint16_t mcp802x_warnings = 0;
volatile uint16_t mcp802x_mode = 0;

extern uint16_t adcVal;
//volatile float current = 1;
volatile int16_t current = 1;

void print_CommState( MCP802X_STATE CommState )
{

    switch(CommState)
    {
        case MCP802X_UNINITIALIZED:
            printf("CommState = UNINITIALIZED" );
            break;
        case MCP802X_INITIALIZATION:
            printf("CommState = INITIALIZATION" );
            break;
        case MCP802X_READY:
            printf("nCommState = READY" );
            break;
        case MCP802X_ERROR:
            printf("nCommState = ERROR" );
            break;
        default:
        {
            printf("CommState = UNKNOWN" );
        }
    }
}
    
void mcp8x_clear_fault()
{
    MCP802X_ENABLE_SetLow(); //disable the gate driver 
    __delay_ms(1);
    MCP802X_ENABLE_SetHigh(); //enable the gate driver 
}
  
void mcp8021_service()
{
    //mcp8021_CommState = MCP802X_eHandleCommunication();

    printf("\r\n");
    print_CommState( mcp8021_CommState );

    if ( PORTDbits.RD1 == 0 )
    {
        printf(" fault_pin = FAULT" );
    }
    else
    {
        printf(" fault_pin = no fault" );
    }

    faultHappen = MCP802X_u16GetLastMcpFaults();

    if (faultHappen != 0)
    {
        printf(" FAULT = %04X", faultHappen );
    }
    mcp802x_warnings = MCP802X_u16GetWarnings();
    printf(" WARNINGS = %04X", mcp802x_warnings );

    mcp802x_mode = MCP802X_sGetMode();
    printf(" MODE = %04X", mcp802x_mode );

    if ( PORTDbits.RD1 == 0 ) // read FAULT pin
    {
        // button pressed
        mcp8x_clear_fault();
        printf("  CLEAR FAULT  " );
    }
}

void change_direction()
{
    //disable PWM generators
        PG1CONLbits.ON = 0;
        PG2CONLbits.ON = 0;
    
        __delay_ms(50);
    //change the mode of the operation    
        PG1IOCONL = PG1IOCONL ^ PG2IOCONL;
        PG2IOCONL = PG1IOCONL ^ PG2IOCONL;
        PG1IOCONL = PG1IOCONL ^ PG2IOCONL;
        
        __delay_ms(50);
    //enable PWM generators
        PG1CONLbits.ON = 1;
        PG2CONLbits.ON = 1;       
        
        printf(" DIRECTION CHANGED " );
}

int main(void)
{
    SYSTEM_Initialize();
    __delay_ms(300);
    __delay_ms(300);
    __delay_ms(300);
    __delay_ms(300);
    __delay_ms(300);
    __delay_ms(300);
 
    printf("\r\n *** START ***** \r\n");
    __delay_ms(100);
    
    //PWMInitialization2();
//    TMR1_Start();
    MCP802X_u8ConfigSet(config1);
    //ChargeBootstarpCapacitors();
    MCP802X_ENABLE_SetHigh(); //enable the gate driver 
    
//    PG1CONLbits.ON = 1;
//    PG2CONLbits.ON = 1;
//    TMR1_Start();
    
    do
    {
        mcp8021_service();
        if ( PORTDbits.RD13 == 0 ) // read SW2
        {
        // button pressed
            change_direction();
        }
        printf("\r\n Motor current = %d\r\n", current);
        //printf("\r\n Motor current = %04X\r\n", adcVal);
        __delay_ms(1);
    }
    while( mcp8021_CommState != MCP802X_READY );
    
    TMR1_Start();
    printf("\r\nCommState = MCP802X_READY" );

    __delay_ms(50);
    
    while(1)
    {
        mcp8021_service();
        
        __delay_ms(10);
    }    
}

//void TMR1_TimeoutCallback(void)
//{
//    mcp8021_CommState = MCP802X_eHandleCommunication(); //call in a low priority timer interrupt  
//}

void ChargeBootstarpCapacitors(void)
{
    uint16_t i = BOOTSTRAP_CHARGING_COUNTS;
    uint16_t prevStatusCAHALF = 0,currStatusCAHALF = 0;
    uint16_t k = 0;
    
    // Enable PWMs only on PWMxL ,to charge bootstrap capacitors at the beginning
    // Hence PWMxH is over-ridden to "LOW"
    PG3IOCONLbits.OVRDAT = 0;  // 0b00 = State for PWM3H,L, if Override is Enabled
    PG2IOCONLbits.OVRDAT = 0;  // 0b00 = State for PWM2H,L, if Override is Enabled
    PG1IOCONLbits.OVRDAT = 0;  // 0b00 = State for PWM1H,L, if Override is Enabled

    PG3IOCONLbits.OVRENH = 1;  // 1 = OVRDAT<1> provides data for output on PWM3H
    PG2IOCONLbits.OVRENH = 1;  // 1 = OVRDAT<1> provides data for output on PWM2H
    PG1IOCONLbits.OVRENH = 1;  // 1 = OVRDAT<1> provides data for output on PWM1H

    PG3IOCONLbits.OVRENL = 1;  // 1 = OVRDAT<0> provides data for output on PWM3L
    PG2IOCONLbits.OVRENL = 1;  // 1 = OVRDAT<0> provides data for output on PWM2L
    PG1IOCONLbits.OVRENL = 1;  // 1 = OVRDAT<0> provides data for output on PWM1L

    // PDCx: PWMx GENERATOR DUTY CYCLE REGISTER
    // Initialize the PWM duty cycle for charging
    INVERTERA_PWM_PDC3 = LOOPTIME_TCY - (DDEADTIME/2 + 5);
    INVERTERA_PWM_PDC2 = LOOPTIME_TCY - (DDEADTIME/2 + 5);
    INVERTERA_PWM_PDC1 = LOOPTIME_TCY - (DDEADTIME/2 + 5);
    
    printf("start\r\n");
    
    while(i)
    {
        //driver status
        mcp8021_CommState = MCP802X_eHandleCommunication(); //call in a low priority timer interrupt
        printf("status= %04X\r\n", mcp8021_CommState);
        
        prevStatusCAHALF = currStatusCAHALF;
        currStatusCAHALF = PG3STATbits.CAHALF;
        if (prevStatusCAHALF != currStatusCAHALF)
        {
            if (currStatusCAHALF == 0)
            {
                i--; 
                k++;
                if (i == (BOOTSTRAP_CHARGING_COUNTS - 50))
                {
                    // 0 = PWM generator provides data for PWM1L pin
                    PG1IOCONLbits.OVRENL = 0;
                }
                else if (i == (BOOTSTRAP_CHARGING_COUNTS - 150))
                {
                    // 0 = PWM generator provides data for PWM2L pin
                    PG2IOCONLbits.OVRENL = 0;  
                }
                else if (i == (BOOTSTRAP_CHARGING_COUNTS - 250))
                {
                    // 0 = PWM generator provides data for PWM3L pin
                    PG3IOCONLbits.OVRENL = 0;  
                }
                if (k > 25)
                {
                    if (PG3IOCONLbits.OVRENL == 0)
                    {
                        if (INVERTERA_PWM_PDC3 > 2)
                        {
                            INVERTERA_PWM_PDC3 -= 2;
                        }
                        else
                        {
                           INVERTERA_PWM_PDC3 = 0; 
                        }
                    }
                    if (PG2IOCONLbits.OVRENL == 0)
                    {
                        if (INVERTERA_PWM_PDC2 > 2)
                        {
                            INVERTERA_PWM_PDC2 -= 2;
                        }
                        else
                        {
                            INVERTERA_PWM_PDC2 = 0; 
                        }
                    }
                    if (PG1IOCONLbits.OVRENL == 0)
                    {
                        if (INVERTERA_PWM_PDC1 > 2)
                        {
                            INVERTERA_PWM_PDC1 -= 2;
                        }
                        else
                        {
                            INVERTERA_PWM_PDC1 = 0; 
                        }
                    }
                    k = 0;
                } 
            }
        }
    }
    // PDCx: PWMx GENERATOR DUTY CYCLE REGISTER
    // Initialize the PWM duty cycle for charging
    INVERTERA_PWM_PDC3 = 0;
    INVERTERA_PWM_PDC2 = 0;
    INVERTERA_PWM_PDC1 = 0;

    PG1IOCONLbits.OVRENH = 1;  // 0 = PWM generator provides data for PWM1H pin
    PG1IOCONLbits.OVRDAT = 1;  // 0b00 = State for PWM3H,L, if Override is Enabled
    PG2IOCONLbits.OVRENH = 0;  // 0 = PWM generator provides data for PWM1H pin
    PG2IOCONLbits.OVRDAT = 0;  // 0b00 = State for PWM2H,L, if Override is Enabled
    //PG2IOCONLbits.OVRDAT = 0;  // 0b00 = State for PWM3H,L, if Override is Enabled
}

void ADC1_ChannelCallback(enum ADC_CHANNEL channel, uint16_t adcVal)
{
    if(channel == Channel_AN15)
    {
        PG1DC = adcVal;
        PG2DC = adcVal;
    }

    if(channel == Channel_AN7)
    {
        //current = ((((float)adcVal - 2048)/4096)*3.3)*100;
        current = adcVal;
    }
}
